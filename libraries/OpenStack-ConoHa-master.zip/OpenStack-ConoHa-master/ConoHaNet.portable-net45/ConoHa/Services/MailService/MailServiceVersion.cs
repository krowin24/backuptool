﻿#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
namespace ConoHaNet.Services.MailService
{
    public class MailServiceVersion
    {
    }
}
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member