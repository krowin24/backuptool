﻿namespace Rackspace.Services.Identity.V2
{
    using System.Runtime.CompilerServices;

    /// <summary>
    /// The <see cref="Rackspace.Services.Identity.V2"/> defines Rackspace-specific extensions to the OpenStack Identity
    /// Service V2.
    /// </summary>
    [CompilerGenerated]
    internal class NamespaceDoc
    {
    }
}
