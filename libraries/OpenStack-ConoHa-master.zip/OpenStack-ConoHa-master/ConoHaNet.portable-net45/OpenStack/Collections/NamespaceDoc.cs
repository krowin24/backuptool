﻿namespace OpenStack.Collections
{
    using System.Runtime.CompilerServices;

    /// <summary>
    /// The <see cref="OpenStack.Collections"/> namespace contains interfaces and
    /// classes that extend the collections support provided by the base class library.
    /// </summary>
    [CompilerGenerated]
    internal class NamespaceDoc
    {
    }
}
