﻿namespace OpenStack.Services.ContentDelivery.V1
{
    using System;
    using Newtonsoft.Json;
    using OpenStack.ObjectModel;

    /// <summary>
    /// Represents the unique identifier of a <see cref="Flavor"/> resource in the Content Delivery Service.
    /// </summary>
    /// <seealso cref="Flavor"/>
    /// <seealso cref="IContentDeliveryService"/>
    /// <threadsafety static="true" instance="false"/>
    /// <preliminary/>
    [JsonConverter(typeof(FlavorId.Converter))]
    public sealed class FlavorId : ResourceIdentifier<FlavorId>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FlavorId"/> class
        /// with the specified identifier value.
        /// </summary>
        /// <param name="id">The identifier value.</param>
        /// <exception cref="ArgumentNullException">If <paramref name="id"/> is <see langword="null"/>.</exception>
        /// <exception cref="ArgumentException">If <paramref name="id"/> is empty.</exception>
        public FlavorId(string id)
            : base(id)
        {
        }

        /// <summary>
        /// Provides support for serializing and deserializing <see cref="FlavorId"/>
        /// objects to JSON string values.
        /// </summary>
        /// <threadsafety static="true" instance="false"/>
        private sealed class Converter : ConverterBase
        {
            /// <inheritdoc/>
            protected override FlavorId FromValue(string id)
            {
                return new FlavorId(id);
            }
        }
    }
}
