﻿namespace OpenStack.IO
{
    using System.Runtime.CompilerServices;

    /// <summary>
    /// The <see cref="OpenStack.IO"/> namespace contains interfaces and
    /// classes that extend the IO support provided by the base class library.
    /// </summary>
    [CompilerGenerated]
    internal class NamespaceDoc
    {
    }
}
