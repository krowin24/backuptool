﻿namespace OpenStack.Net
{
    using System.Runtime.CompilerServices;

    /// <summary>
    /// The <see cref="OpenStack.Net"/> namespace contains interfaces and classes to support sending HTTP web requests
    /// and processing the results.
    /// </summary>
    [CompilerGenerated]
    internal class NamespaceDoc
    {
    }
}
