﻿install-package Newtonsoft.Json
install-package Microsoft.Net.Http
Install-Package Rackspace.Net.UriTemplate -Pre 
Install-Package Rackspace.Threading -Pre 