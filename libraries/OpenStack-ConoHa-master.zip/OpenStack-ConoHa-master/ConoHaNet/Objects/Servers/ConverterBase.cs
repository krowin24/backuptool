﻿namespace ConoHaNet.Objects.Servers
{
    internal class ConverterBase
    {
    }
}