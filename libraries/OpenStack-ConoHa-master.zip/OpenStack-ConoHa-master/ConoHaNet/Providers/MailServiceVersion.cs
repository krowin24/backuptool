﻿#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
namespace ConoHaNet.Providers
{
    public class MailServiceVersion
    {
    }
}
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member